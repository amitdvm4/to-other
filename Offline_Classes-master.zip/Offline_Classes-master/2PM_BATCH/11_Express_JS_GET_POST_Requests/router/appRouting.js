const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const urlencodedParser = bodyParser.urlencoded({ extended: false });

let mapRoutes = (app) => {
    // home page
    app.get('/', (request , response) => {
        response.sendFile(path.join(__dirname , '..' , 'views' ,  'index.html'));
    });

    // about page
    app.get('/about', (request , response) => {
        response.sendFile(path.join(__dirname , '..' , 'views' ,  'about.html'));
    });

    // profile page
    app.get('/profile', (request , response) => {
        response.sendFile(path.join(__dirname ,'..' , 'views' ,  'profile.html'));
    });

    // profile page with request parameters
    app.get('/profile/:id', (request , response) => {
        let personId = Number.parseInt(request.params.id);
        console.log(typeof personId);
        fs.readFile(path.join(__dirname , '..' , 'data' , 'persons.json') , 'utf8' , (err , data) => {
            if(err) throw  err;
            let persons = JSON.parse(data);
            let selectedPerson = persons.find((person) => {
                return person.id === personId;
            });
            console.log(selectedPerson);
        });
        response.sendFile(path.join(__dirname ,'..' , 'views' ,  'profile.html'));
    });

    // services page with query strings
    app.get('/services', (request , response) => {
        let queryObject = request.query;
        console.log(queryObject);
        response.sendFile(path.join(__dirname ,'..' , 'views' ,  'services.html'));
    });

    // contact page
    app.get('/contact', (request , response) => {
        response.sendFile(path.join(__dirname , '..' ,  'views' ,  'contact.html'));
    });

    // contact Form
    app.post('/contact-form' , urlencodedParser , (request , response) => {
        let contactInfo = request.body;
        console.log(contactInfo);
        response.render(path.join(__dirname , '..' ,  'views' ,  'contact-success.ejs') , {contactInfo : contactInfo});
    });

    // 404 page
    app.use((request , response) => {
        response.sendFile(path.join(__dirname , '..' , 'views' ,  '404.html'));
    });
};

module.exports = {
    mapRoutes
};