const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const urlencodedParser = bodyParser.urlencoded({ extended: false });

// list of contacts
let contactList = [];

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index.ejs');
});

/* GET About page. */
router.get('/about', function(req, res, next) {
  res.render('about.ejs');
});

/* GET Profile page. */
router.get('/profile', function(req, res, next) {
  let selectedPerson = {
    id : '',
    first_name : '',
    last_name : '',
    email : '',
    gender : '',
    ip_address : ''
  };
  res.render('profile.ejs' , {selectedPerson : selectedPerson});
});

/* GET Profile page with Parameters. */
router.get('/profile/:id', function(req, res, next) {
  let personId = Number.parseInt(req.params.id);
  fs.readFile(path.join(__dirname , '..' , 'data' , 'persons.json') , 'utf8' , (err , data) => {
    if(err) throw  err;
    let persons = JSON.parse(data);
    let selectedPerson = persons.find((person) => {
      return person.id === personId;
    });
    res.render('profile.ejs' , {selectedPerson : selectedPerson});
  });

});

/* GET Services page. */
router.get('/services', function(req, res, next) {
  res.render('services.ejs' , {contactList : contactList});
});

/* GET contact page. */
router.get('/contact', function(req, res, next) {
  res.render('contact.ejs');
});

/* POST contact form. */
router.post('/contact-form', urlencodedParser , function(req, res, next) {
    let contactInfo = req.body;
    // push the contactInfo to contactList
    contactList.push(contactInfo);
    res.render('contact-success.ejs' , {contactInfo : contactInfo});
});

module.exports = router;
