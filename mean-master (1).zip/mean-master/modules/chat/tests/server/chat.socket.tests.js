'use strict';

/**
 * Chat socket tests
 */
describe('Chat Socket Tests:', function () {

  // TODO: Add chat socket tests
});
